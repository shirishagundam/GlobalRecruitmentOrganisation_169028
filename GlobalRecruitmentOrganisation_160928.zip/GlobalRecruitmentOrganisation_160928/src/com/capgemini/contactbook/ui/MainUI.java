package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;

public class MainUI {
	static Logger logger = Logger.getLogger(MainUI.class);

	public static void main(String[] args) throws ContactBookException {

		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");
		Scanner scanner = new Scanner(System.in);

		ContactBookService service = new ContactBookServiceImpl();
		while (true) {
			System.out.println("Global Recruitments");
			System.out.println("1.		Enter Enquiry Details");
			System.out.println("2.		View Enquiry Details on id");
			System.out.println("0.		Exit");

			System.out.println("Please enter a choice: ");
			int choice = 0;
			try {
				choice = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Enter only digits");
				System.exit(0);
			}
			switch (choice) {
			case 0:
				System.out.println("Exited from operation successfully");
				System.exit(0);
				break;

			case 1:
				scanner.nextLine();
				System.out.println("Enter First name: ");
				String firstName = scanner.nextLine();
				System.out.println("Enter Last name: ");
				String lastName = scanner.nextLine();
				System.out.println("Contact Number: ");
				String contactNo = null;
				try {
					contactNo = scanner.nextLine();
				} catch (InputMismatchException e) {
					System.err
							.println("Phone number should contain digits only");
					System.exit(0);
				}
				System.out.println("Enter preferred Domain: ");
				String domain = scanner.nextLine();
				System.out.println("Enter Preferred Location: ");
				String location = scanner.nextLine();
				

				EnquiryBean enqry = new EnquiryBean();
				enqry.setfName(firstName);
				enqry.setlName(lastName);
				enqry.setContactNo(contactNo);
				enqry.setpDomain(domain);
				enqry.setpLocation(location);

				try {
					boolean result = service.isValidEnquiry(enqry);

					if (result) {
						int enqryId = service.addEnquiry(enqry);
						System.out.println("Thank you " + firstName + " "
								+ lastName + " your unique ID is " + enqryId
								+ " we will contact you shortly.");
					}
				} catch (Exception e) {// malli chuudu
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enetr the Enquiry No:");
				int enquiryNo = 0;
				try {
					enquiryNo = scanner.nextInt();
				} catch (InputMismatchException e) {
					System.err.println("Enter only digits");
					System.exit(0);
				}

				EnquiryBean enquiry;
				try {
					enquiry = service.getEnquiryDetails(enquiryNo);
					System.out.println(enquiry);

				} catch (Exception e) {
					System.err.println(e.getMessage());
				}

				break;
			default:
				System.out.println("Invalid option");
				break;
			}
		}
	}
}
